package com.example.exosldnrarccomp.entityTables;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;


// Représente une table
@Entity(tableName = "word_table")
public class Word {

    // champ id autoIncrémenté
    @PrimaryKey(autoGenerate = true)
    private int wordId;

    // ne pouvant pas être null
    @NonNull
    // donne un nom à la colonne
    @ColumnInfo(name = "word")
    private String mWord;

    // Contructeur
    public Word(int wordId, @NonNull String mWord) {
        this.wordId = wordId;
        this.mWord = mWord;
    }

    public int getWordId() {
        return this.wordId;
    }

    public String getWord() {
        return this.mWord;
    }
}
